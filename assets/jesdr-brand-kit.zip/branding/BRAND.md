# jeSDR brand kit

The jeSDR logo, icons and colors, for the website, the radio's web UI, club
newsletters, talks and reviews.

![jeSDR brand sheet](jesdr-brand-sheet.png)

## The name

Write it **jeSDR**: lower-case *je*, capital *SDR*, no space. Not JeSDR, JESDR or
je-SDR. In running text it needs no explanation; where it helps, add "software
for the sBitx HF transceiver".

## Files

| File | Use |
|---|---|
| `jesdr-logo.png` (1774 × 847), `-1200`, `-600`, `-300` | The logo, transparent. For **light** backgrounds. |
| `jesdr-logo-dark.png` (1792 × 865), `-1200`, `-600`, `-300` | The logo with a white outline, transparent. For **dark** or busy backgrounds and photos; it also works on light ones. |
| `jesdr-mark.png` | The tower and waves alone, transparent. For places where the name is already written next to it. |
| `jesdr-icon-1024.png` … `jesdr-icon-16.png` | The app icon: the mark on a white rounded tile. Desktop and menu icon, browser tab, phone home screen. |
| `favicon.ico` | 16, 32, 48 and 64 px in one file, for browsers. |
| `jesdr-social.png` (1200 × 630) | Link preview card (Open Graph). |
| `jesdr-brand-sheet.png` | This page's overview. |

Where they are used:

- Website (drexjj/jeSDR): `assets/` (logo in the menu bar, the hero and the
  footer; favicon; link preview), and `assets/jesdr-brand-kit.zip`, a copy of
  this folder for download.
- Radio web UI: `web/brand/` (favicon, phone home-screen icon, the About page
  and the "Connecting…" screen).
- Package: `build_deb.sh` installs `jesdr-icon-{48,64,128,256,512}.png` as the
  `jesdr` icon in `/usr/share/icons/hicolor`, for the menu entry and the
  desktop shortcut.

## Colors

Taken from the logo. On screen use the hex values.

| Name | Hex | Where in the logo | Use |
|---|---|---|---|
| Sky | `#19D0FC` | top of *SDR*, inner waves | links, highlights on dark backgrounds |
| Signal blue | `#0093FD` | *SDR* | main brand blue |
| Deep blue | `#0052FC` | bottom of *SDR*, outer waves | gradients, pressed states |
| Navy | `#0032AD` | wave shadows | dark accents |
| Yellow | `#FDD003` | swoosh, top | hover, small accents |
| Amber | `#FDB906` | swoosh | primary buttons, frequencies, tags |
| Orange | `#F86200` | swoosh, lower edge | warnings, sparingly |
| Silver | `#E8EAEF` | *je* | text on dark |
| Steel | `#CED2DC` | *je* shading | secondary text on dark |
| Outline | `#0B1013` | the black outline | dark backgrounds (the site uses `#0B0F14`) |

The blues are the brand; amber/yellow is the accent and should cover much
less area than the blues. Body text on dark backgrounds is `#E6EDF3`.

## Type

The logo's lettering is artwork. Don't try to set "jeSDR" in a font to look
like it; use the logo file. Around it:

- **Text:** the system sans-serif (`system-ui, -apple-system, "Segoe UI",
  Roboto, Arial, sans-serif`), as the website and web UI do.
- **Frequencies, commands, settings:** a monospace (`ui-monospace, "SF Mono",
  "Cascadia Mono", Menlo, Consolas, monospace`).

## Using the logo

- **Space:** keep clear space around the logo of at least the height of the
  *e* (about a quarter of the logo's height).
- **Smallest size:** the full logo 120 px wide on screen (25 mm in print).
  Smaller than that, use the icon.
- **Backgrounds:** the plain logo on white or light gray; the outlined (dark)
  version on anything dark, colorful or photographic. The black tower
  disappears on dark backgrounds without the outline.
- **Don't** stretch or squash it, recolor it, rotate it, add effects, rearrange
  the tower and the name, or put the plain version on a dark background.
- The icon stays on its white tile; don't put the tile on a white page with no
  border.

## Credit and copyright

jeSDR is Copyright © 2026 J. Kujawa, W9JES. Built on the sBitx software
created by Ashhar Farhan, VU2ESE. Enhanced code by J. Kujawa, W9JES, with
contributions from Jon W2JON, Alan N1QM, Lee W4WHL, Matt NM7D, Lars OZ7BX,
Jeff KF7DYU, Mike KB2ML, Shawn K7IHZ, Jared KJ5DTK, Fabrizio F4VUK, Bob KD8CGH,
Bob W7PUA, Phil KA9Q, Gerald K5SDR, Steve N3SB and Juan WP3DN. Thanks, with
gratitude, to the community members of the Radio & Electronics Hub on Discord
for their help and support.

You may use the logo to refer to jeSDR: in articles, reviews, talks, club
newsletters and links to the project. Please don't use it for other products,
or in a way that suggests the project endorses something it doesn't. jeSDR is
not affiliated with the makers of the sBitx.

## Making the files again

The files come from the original artwork (a transparent PNG at 1774 × 887 or
larger). The outlined version adds a 7 px white outline at full size; the icon
puts the tower and waves on a 1024 px white tile with 200 px corners and a
yellow swoosh at the foot, then scales down. Replace the PNGs here and in
`web/brand/` and the website's `assets/` together.
